#!/usr/bin/env bash
# Mix final do M1: voz + trilha (com ducking pela voz) + efeitos → mix.wav, normalizado em -14 LUFS / -1 dBTP.
# Rode da pasta do projeto: bash assets/audio/mix.sh
set -euo pipefail
cd "$(dirname "$0")"
K=../../../../kit/audio
DUR=22.5
VO_AT=1.0           # início da voz (s)
TRILHA_AT=0.225     # alinha um tempo da trilha (96 BPM) com o corte da cena 3 (4,6s)
TICKS=(9.05 11.66 14.48)  # entrada de cada tópico

ms() { python3 -c "print(int(round($1*1000)))"; }

inputs=(-i vo.mp3 -i "$K/trilha-korza-01.wav" -i "$K/notificacao.wav")
filt="[0:a]aresample=48000,aformat=channel_layouts=stereo,adelay=$(ms $VO_AT)|$(ms $VO_AT),apad=whole_dur=$DUR,asplit=2[vo][vosc];"
filt+="[1:a]adelay=$(ms $TRILHA_AT)|$(ms $TRILHA_AT),volume=0.30,apad=whole_dur=$DUR[mus];"
filt+="[mus][vosc]sidechaincompress=threshold=0.03:ratio=4:attack=20:release=350[musd];"
filt+="[2:a]adelay=50|50,volume=0.55,apad=whole_dur=$DUR[nt];"
inputs+=(-i "$K/notificacao.wav")   # push da loja chegando (cena 2)
filt+="[3:a]adelay=6950|6950,volume=0.35,apad=whole_dur=$DUR[nt2];"
mixin="[vo][musd][nt][nt2]"
i=4
for t in "${TICKS[@]}"; do
  inputs+=(-i "$K/tick.wav")
  filt+="[$i:a]adelay=$(ms $t)|$(ms $t),volume=0.18,apad=whole_dur=$DUR[t$i];"
  mixin+="[t$i]"
  i=$((i + 1))
done
filt+="${mixin}amix=inputs=$((i)):normalize=0,atrim=0:$DUR,afade=t=out:st=$(python3 -c "print($DUR-0.6)"):d=0.6[pre]"

ffmpeg -v error -y "${inputs[@]}" -filter_complex "$filt" -map "[pre]" -ar 48000 pre.wav

# loudnorm em duas passadas
read -r I TP LRA THR OFF < <(ffmpeg -hide_banner -i pre.wav -af loudnorm=I=-14:TP=-1:LRA=11:print_format=json -f null - 2>&1 |
  python3 -c 'import sys,json,re; d=json.loads(re.search(r"\{.*\}", sys.stdin.read(), re.S).group()); print(d["input_i"], d["input_tp"], d["input_lra"], d["input_thresh"], d["target_offset"])')
ffmpeg -v error -y -i pre.wav -af "loudnorm=I=-14:TP=-1:LRA=11:measured_I=$I:measured_TP=$TP:measured_LRA=$LRA:measured_thresh=$THR:offset=$OFF:linear=true" -ar 48000 mix.wav
rm pre.wav
ffmpeg -hide_banner -i mix.wav -af ebur128=peak=true -f null - 2>&1 | grep -E "^\s+(I:|Peak:)" | tr -s ' '
